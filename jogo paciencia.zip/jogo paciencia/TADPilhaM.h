
struct TpPilhaM{
	int TOPO1, TOPO2;
	TpCarta cartaM[MAXCARTA];
};

void InicializarM(TpPilhaM &PM){
	PM.TOPO1 = -1;
	PM.TOPO2 = MAXCARTA;
}

void PushM(TpPilhaM &PM, TpCarta elemento, int NP){ //insere
	if(NP == 1) //''NP'' seleciona qual das pilhas ser�o trabalhadas
		PM.cartaM[++PM.TOPO1] = elemento;
	else
		PM.cartaM[--PM.TOPO2] = elemento;
}

TpCarta PopM(TpPilhaM &PM, int NP){ //retira
	if(NP == 1)
		return PM.cartaM[PM.TOPO1--];
	else
		return PM.cartaM[PM.TOPO2++];
}

TpCarta ElementoTopoM(TpPilhaM PM, int NP){
	if(NP == 1)
		return PM.cartaM[PM.TOPO1];
	else
		return PM.cartaM[PM.TOPO2];
}

char PMCheiaM(int topo1, int topo2){
	return topo1+1 == topo2; // ou se o topo1 == topo2-1
}

char PMVaziaM(int topo, int NP){ //quando for chamada deve especificar qual topo ser� utilizado
	if(NP == 1)
		return topo == -1; 
	else
		return topo == MAXCARTA;
}

int PMQuantidadeElementosM(int topo,int topo2){ //quando for chamada deve especificar qual topo ser� utilizado
	return (topo)+(MAXCARTA-topo2);
	
}

void PMExibirM(TpPilhaM PM, int NP){
	if(NP == 1) //exibe os char da pilha 1
		while(!PMVaziaM(PM.TOPO1,NP))
			printf("\n%c", PopM(PM,NP));	
	else //exibe os char da pilha 2
		while(!PMVaziaM(PM.TOPO2,NP))
			printf("\n%c", PopM(PM,NP));
}
