#define MAXCARTA 60

//STRUCTS
struct TpCarta{
	char naipe; // C, O, P, E
	int numero; // A=1, 2, 3, 4, 5, 6, 7, 8, 9, 10, J=11, Q=12, K=13
};

struct TpPilha{
	int topo;
	TpCarta carta[MAXCARTA];
};


//FUN�OES
void Inicializar(TpPilha &pilhaC){
	pilhaC.topo = -1;
}

void Push(TpPilha &pilhaC, TpCarta elemento){
	pilhaC.carta[++pilhaC.topo] = elemento;
}

TpCarta Pop(TpPilha &pilhaC){
	return pilhaC.carta[pilhaC.topo--];
}

TpCarta ElementoTopo(TpPilha &pilhaC){
	return pilhaC.carta[pilhaC.topo];
}

char PilhaCheia(int topo){
	return topo == MAXCARTA-1;
}

char PilhaVazia(int topo){
	return topo == -1;
}

void ExibePilha(TpPilha pilhaC){
	TpCarta aux;
	while(!PilhaVazia(pilhaC.topo)){
		aux = Pop(pilhaC);
		printf("%d %c", aux.numero, aux.naipe);
	}
}
