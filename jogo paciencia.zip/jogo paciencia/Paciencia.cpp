#include <stdio.h>
#include <conio2.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
//***********************************************************************
#include "TADPilha1.h" //tad pilha b�sico
#include "TADPilhaM.h" //tad pilha 2 topos
//***********************************************************************

void Moldura(void)//colocar pra inserir dps as pilhas com as cartas e ja printar tudo
{
    clrscr();
    int x=1,y=1;
    for(y=2;y<60;y++){
        x=1;
        gotoxy(x,y);printf("%c",186);
        x=119;
        gotoxy(x,y);printf("%c",186);
    }

    for(x=2;x<119;x++){
        y=1;
        gotoxy(x,y);printf("%c",205);
        y=60;
        gotoxy(x,y);printf("%c",205);
    }
    //bordas padroes
    gotoxy(1,1);printf("%c",201);
    gotoxy(119,1);printf("%c",187);
    gotoxy(1,60);printf("%c",200);
    gotoxy(119,60);printf("%c",188);
    //bordas baralho
    gotoxy(18,1);printf("%c",203);
    gotoxy(18,60);printf("%c",202);
    for(y=2;y<60;y++){
        x=18;
        gotoxy(x,y);printf("%c",186);
    }

    gotoxy(102,1);printf("%c",203);
    gotoxy(102,60);printf("%c",202);
    for(y=2;y<60;y++){
        x=102;
        gotoxy(x,y);printf("%c",186);
    }
    // quadrante 4
    
    
    
    for(y=50;y<59;y++){
        x=19;
        gotoxy(x,y);printf("%c",186);
        x=101;
        gotoxy(x,y);printf("%c",186);
    }

    for(x=19;x<101;x++){
        y=50;
        gotoxy(x,y);printf("%c",205);
        y=59;
        gotoxy(x,y);printf("%c",205);
    }
    
    gotoxy(19,50);printf("%c",201);
    gotoxy(101,50);printf("%c",187);
    gotoxy(19,59);printf("%c",200);
    gotoxy(101,59);printf("%c",188);
    
    
    for(x=20;x<101;x++){
        y=57;
        gotoxy(x,y);printf("%c",205);
    }
    gotoxy(19,57);printf("%c",204);
    gotoxy(101,57);printf("%c",185);
    
    
    
    printf("\n");
}

void limparquadrante1(void){
	int x=0,y=0;
	for(x=2;x<18;x++){
		for(y=2;y<30;y++){
			gotoxy(x,y);printf(" ");
		}
	}
}

void limparquadrante2(void){
	int x=0,y=0;
	for(x=19;x<102;x++){
		for(y=2;y<50;y++){
			gotoxy(x,y);printf(" ");
		}
	}
}

void limparquadrante3(void){
	int x=0,y=0;
	for(x=103;x<119;x++){
		for(y=2;y<30;y++){
			gotoxy(x,y);printf(" ");
		}
	}
}

void limparquadrante4(void){
	int x=0,y=0;
	for(x=20;x<101;x++){
		for(y=51;y<57;y++){
			gotoxy(x,y);printf(" ");
		}
	}
}

void digitar(void){
	int x;
	for(x=20;x<101;x++){
		gotoxy(x,58);printf(" ");
	}
	gotoxy(20,58);
}

void PrintarMesa(TpPilhaM mesa,int pos){//TEM COISA PRA TIRAR DPS
    int x=22+pos*12,y=4,j;
    
    char aux;
	TpCarta carta;
	TpPilha aux3;
	Inicializar(aux3);
	gotoxy(x,y-2);printf("[#%d]",pos+1);


	for(j=0;j<=mesa.TOPO1;j++){//printar carta nao revelada
		gotoxy(x,y);printf("%c%c%c%c",218,196,196,191);y++;
		gotoxy(x,y);printf("|--|");y++;
	}
	
	if(!PMVaziaM(mesa.TOPO2,2)){
		while(!PMVaziaM(mesa.TOPO2,2)){//inverte pilha
			Push(aux3,PopM(mesa,2));
		}
	
	
		while(!PilhaVazia(aux3.topo)){//printar carta revelada
			carta = Pop(aux3);
			if(carta.naipe == 'C'|| carta.naipe == 'O')
				textcolor(4);
			else
				textcolor(1);
			if(carta.numero==10){// se for 10
				gotoxy(x,y);printf("%c%c%c%c%c",218,196,196,196,191);y++;
			}else{
				gotoxy(x,y);printf("%c%c%c%c",218,196,196,191);y++;
			}
			textcolor(7);
			if(carta.numero>=11||carta.numero==1){
				switch(carta.numero){
					case 11:
						aux = 'J';
						break;
					case 12:
						aux = 'Q';
						break;
					case 13:
						aux = 'K';
						break;
					case 1:
						aux = 'A';
						break;
				}
				switch(carta.naipe){
					case 'C':
						textcolor(4);
						gotoxy(x,y);printf("|%c%c|",aux,3);y++;
						textcolor(7);
						break;
					case 'O':
						textcolor(4);
						gotoxy(x,y);printf("|%c%c|",aux,4);y++;
						textcolor(7);
						break;
					case 'P':
						textcolor(1);
						gotoxy(x,y);printf("|%c%c|",aux,5);y++;
						textcolor(7);
						break;
					case 'E':
						textcolor(1);
						gotoxy(x,y);printf("|%c%c|",aux,6);y++;
						textcolor(7);
						break;
				}
			}else{
				switch(carta.naipe){
					case 'C':
						textcolor(4);
						gotoxy(x,y);printf("|%d%c|",carta.numero,3);y++;
						textcolor(7);
						break;
					case 'O':
						textcolor(4);
						gotoxy(x,y);printf("|%d%c|",carta.numero,4);y++;
						textcolor(7);
						break;
					case 'P':
						textcolor(1);
						gotoxy(x,y);printf("|%d%c|",carta.numero,5);y++;
						textcolor(7);
						break;
					case 'E':
						textcolor(1);
						gotoxy(x,y);printf("|%d%c|",carta.numero,6);y++;
						textcolor(7);
						break;
				}	
			}
			if(carta.naipe == 'C'|| carta.naipe == 'O')
				textcolor(4);
			else
				textcolor(1);
				
			if(carta.numero==10){
				gotoxy(x,y);printf("%c%c%c%c%c",192,196,196,196,217);y++;
			}else{
				gotoxy(x,y);printf("%c%c%c%c",192,196,196,217);y++;
			}
			textcolor(7);
			}
		
	}
}

void PrintarNaipes(TpPilha naipe,int pos){//PRECISA TESTAR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    int x=108,y;
    int j;
    char aux;
	TpCarta carta;
	
    switch(pos){
        case 0://C
        textcolor(4);
            y=5;
            break;
        case 1://O
        textcolor(4);
            y=11;
            break;
        case 2://P
        textcolor(1);
            y=18;
            break;
        case 3://E
         textcolor(1);
            y=24;
            break;
    }
    
    
	if(PilhaVazia(naipe.topo)){
		gotoxy(x,y);printf("%c%c%c%c",218,196,196,191);y++;
		
		switch(pos){
					case 0:
						gotoxy(x,y);printf("|-%c| [#8]",3);y++;
						break;
					case 1:
						gotoxy(x,y);printf("|-%c| [#9]",4);y++;
						break;
					case 2:
						gotoxy(x,y);printf("|-%c| [#10]",5);y++;
						break;
					case 3:
						gotoxy(x,y);printf("|-%c| [#11]",6);y++;
						break;
				}
		
		gotoxy(x,y);printf("%c%c%c%c",192,196,196,217);y++;
		
	}else{
			carta = Pop(naipe);
			if(carta.numero==10){
				gotoxy(x,y);printf("%c%c%c%c%c",218,196,196,196,191);y++;
			}else{
				gotoxy(x,y);printf("%c%c%c%c",218,196,196,191);y++;
			}
			if(carta.numero>=11||carta.numero==1){
				switch(carta.numero){
					case 11:
						aux = 'J';
						break;
					case 12:
						aux = 'Q';
						break;
					case 13:
						aux = 'K';
						break;
					case 1:
						aux = 'A';
						break;
				}
				switch(carta.naipe){
					case 'C':
						gotoxy(x,y);printf("|%c%c| [#8]",aux,3);y++;
						break;
					case 'O':
						gotoxy(x,y);printf("|%c%c| [#9]",aux,4);y++;
						break;
					case 'P':
						gotoxy(x,y);printf("|%c%c| [#10]",aux,5);y++;
						break;
					case 'E':
						gotoxy(x,y);printf("|%c%c| [#11]",aux,6);y++;
						break;
				}
			}else{
				switch(carta.naipe){
					case 'C':
						gotoxy(x,y);printf("|%d%c| [#8]",carta.numero,3);y++;
						break;
					case 'O':
						gotoxy(x,y);printf("|%d%c| [#9]",carta.numero,4);y++;
						break;
					case 'P':
						gotoxy(x,y);printf("|%d%c| [#10]",carta.numero,5);y++;
						break;
					case 'E': 
						gotoxy(x,y);printf("|%d%c| [#11]",carta.numero,6);y++;
						break;
				}	
			}
		
		if(carta.numero==10){
			gotoxy(x,y);printf("%c%c%c%c%c",192,196,196,196,217);y++;
		}else{
			gotoxy(x,y);printf("%c%c%c%c",192,196,196,217);y++;
		}
	}
 		textcolor(7);
    }

void PrintarMontante(TpPilha montante,TpPilha resto){
	int x=5, y=5;
	TpCarta carta;
	char aux;
	gotoxy(x,y-2);printf("  [#12]   ");
	gotoxy(x,y);printf("Montante:");y++;y++; x=7;
	gotoxy(x,y);printf("%c%c%c%c%c",218,196,196,196,191);y++;
	if(montante.topo>8){
	
	gotoxy(x,y);printf("| %d|", montante.topo+1);y++;
	}
	else{
	
	gotoxy(x,y);printf("|  %d|", montante.topo+1);y++;
	}
	gotoxy(x,y);printf("%c%c%c%c%c",192,196,196,196,217);y++;
	
	//printar resto
	
	
	if(!PilhaVazia(resto.topo)){
	carta = ElementoTopo(resto);
			if(carta.naipe == 'C'|| carta.naipe == 'O')
				textcolor(4);
			else
				textcolor(1);
			if(carta.numero==10){// se for 10
				gotoxy(x,y);printf("%c%c%c%c%c",218,196,196,196,191);y++;
			}else{
				gotoxy(x,y);printf("%c%c%c%c",218,196,196,191);y++;
			}
			textcolor(7);
			if(carta.numero>=11||carta.numero==1){
				switch(carta.numero){
					case 11:
						aux = 'J';
						break;
					case 12:
						aux = 'Q';
						break;
					case 13:
						aux = 'K';
						break;
					case 1:
						aux = 'A';
						break;
				}
				switch(carta.naipe){
					case 'C':
						textcolor(4);
						gotoxy(x,y);printf("|%c%c|",aux,3);y++;
						textcolor(7);
						break;
					case 'O':
						textcolor(4);
						gotoxy(x,y);printf("|%c%c|",aux,4);y++;
						textcolor(7);
						break;
					case 'P':
						textcolor(1);
						gotoxy(x,y);printf("|%c%c|",aux,5);y++;
						textcolor(7);
						break;
					case 'E':
						textcolor(1);
						gotoxy(x,y);printf("|%c%c|",aux,6);y++;
						textcolor(7);
						break;
				}
			}else{
				switch(carta.naipe){
					case 'C':
						textcolor(4);
						gotoxy(x,y);printf("|%d%c|",carta.numero,3);y++;
						textcolor(7);
						break;
					case 'O':
						textcolor(4);
						gotoxy(x,y);printf("|%d%c|",carta.numero,4);y++;
						textcolor(7);
						break;
					case 'P':
						textcolor(1);
						gotoxy(x,y);printf("|%d%c|",carta.numero,5);y++;
						textcolor(7);
						break;
					case 'E':
						textcolor(1);
						gotoxy(x,y);printf("|%d%c|",carta.numero,6);y++;
						textcolor(7);
						break;
				}	
			}
			if(carta.naipe == 'C'|| carta.naipe == 'O')
				textcolor(4);
			else
				textcolor(1);
				
			if(carta.numero==10){
				gotoxy(x,y);printf("%c%c%c%c%c",192,196,196,196,217);y++;
			}else{
				gotoxy(x,y);printf("%c%c%c%c",192,196,196,217);y++;
			}
			textcolor(7);
			}
	}
		

void Printarquadrante1(TpPilha montante,TpPilha resto){
	limparquadrante1();
	PrintarMontante(montante,resto);
	
}

void Printarquadrante2(TpPilhaM mesa[]){
    int i;
    limparquadrante2();
    for(i=0;i<7;i++)
		PrintarMesa(mesa[i],i);
}

void Printarquadrante3(TpPilha naipes[]){
    int i;
    limparquadrante3();
    for(i=0;i<4;i++)
        PrintarNaipes(naipes[i],i);
}

void RetornarBarallhoAleatorio(TpPilha &montante){
    int i,j;
    TpCarta carta; TpCarta temp;
    char naipes[4] = {'C', 'O', 'P', 'E'};
    for(i=0; i<4; i++){
    	for(j=1; j<=13; j++){
    		carta.naipe = naipes[i];
            carta.numero = j;
            Push(montante, carta);
		}
	}
	
	for (i = montante.topo; i > 0; i--) {
        j = rand() % i; // Gera um �ndice aleat�rio entre 0 e i
        temp = montante.carta[i]; // Troca as cartas nas posi��es i e j
        montante.carta[i] = montante.carta[j];
        montante.carta[j] = temp;
    }
}

void buffer(void){
	int x=0,y=62;
	for(x=0;x<30;x++)
		for(y=62;y<75;y++){
			gotoxy(x,y);printf(" ");
			}
	gotoxy(1,62);
}

void mesaPmesa(TpPilhaM &mesa1, TpPilhaM &mesa2, int  qtd){
	//mesa 1 = orig // mesa 2 = dest
	int x,y,i,j;
	TpPilha aux69;
	Inicializar(aux69);
	j = MAXCARTA-mesa1.TOPO2;
	if( qtd <= j && qtd > 0){//valido
	//****************************************************************************************************
		for(i=0;i<qtd;i++){//colocar em aux para dar certo
			Push(aux69,PopM(mesa1,2));
		}
		if(!PMVaziaM(mesa2.TOPO2,2)){
			if(ElementoTopo(aux69).naipe == 'C' || ElementoTopo(aux69).naipe == 'O')
			{// se for vermelho
					if((ElementoTopoM(mesa2,2).naipe == 'P'|| ElementoTopoM(mesa2,2).naipe == 'E') && (ElementoTopoM(mesa2,2).numero == ElementoTopo(aux69).numero+1) ){
						// e o outro � preto e � +1 que o orig // TROCA
						for(i=0;i<qtd;i++){//pegar tudo do aux e colocar na mesa
							PushM(mesa2,Pop(aux69),2);
						}
						
						if(PMVaziaM(mesa1.TOPO2,2) && !PMVaziaM(mesa1.TOPO1,1))
							PushM(mesa1,PopM(mesa1,1),2);
						
					}else{
						for(i=0;i<qtd;i++){//voltando a carta
						PushM(mesa1,Pop(aux69),2);
						}
						
						x=21,y=54;
						limparquadrante4();
						gotoxy(x,y);printf("Nao e possivel fazer o movimento!!");
						digitar();
						getch();
					}
			}
			else
			{ // se for preto
				if((ElementoTopoM(mesa2,2).naipe == 'C'|| ElementoTopoM(mesa2,2).naipe == 'O') && (ElementoTopoM(mesa2,2).numero == ElementoTopo(aux69).numero+1) ){
				// e o outro � vermelho e � +1 que o orig //TROCA
					for(i=0;i<qtd;i++){
						PushM(mesa2,Pop(aux69),2);
					}
					if(PMVaziaM(mesa1.TOPO2,2) && !PMVaziaM(mesa1.TOPO1,1))
						PushM(mesa1,PopM(mesa1,1),2);
				}
				else{
					for(i=0;i<qtd;i++){//voltando a carta
					PushM(mesa1,Pop(aux69),2);
					}
					
					x=21,y=54;
					limparquadrante4();
					gotoxy(x,y);printf("Nao e possivel fazer o movimento!!");
					digitar();
					getch();
				}
				
			}
		}else{ // se mesa 2 for vazia 
			if(ElementoTopo(aux69).numero==13){//ver se o elemento que esta movendo � K
				for(i=0;i<qtd;i++){
					PushM(mesa2,Pop(aux69),2);
				}
			if(PMVaziaM(mesa1.TOPO2,2) && !PMVaziaM(mesa1.TOPO1,1))
							PushM(mesa1,PopM(mesa1,1),2);
			}else{//so volta do aux para pilha e fala q deu merda
				for(i=0;i<qtd;i++){//voltando a carta
					PushM(mesa1,Pop(aux69),2);
					}
					
					x=21,y=54;
					limparquadrante4();
					gotoxy(x,y);printf("Nao e possivel fazer o movimento!!");
					digitar();
					getch();
			}
		}
	//****************************************************************************************************	
	}else{// ele quer manipular mais cartas doq tem
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("DIGITE UMA QUANTIDADE VALIDA (enter - sair)");
		digitar();
		getch();
	}
	
}

void mesaPnaipe(TpPilhaM &mesa, TpPilha &naipe,int tiponaipe){
	// entra a mesa orig
	// entra o naipe escolhido
	// entra o indice do naipe escolhido C=0 O=1 P=2 E=3
	char tiponaipechar;
	int x,y;
	switch(tiponaipe){
		case 0:
			tiponaipechar = 'C';
			break;
		case 1:
			tiponaipechar = 'O';
			break;
		case 2:
			tiponaipechar = 'P';
			break;
		case 3:
			tiponaipechar = 'E';
			break;
	}
	
	if(!PMVaziaM(mesa.TOPO2,2)){// se a mesa nao estiver vazia ele manda pro naipe
	
	//***************************************************************************************
	//       TEM QUE FAZER 2 VERIFICA�OES DIFERENTES PQ SE NAO ELE PEGA LIXO!!!!!!!!!!
	//***************************************************************************************
	
		if(PilhaVazia(naipe.topo)){// se a pilha estiver vazia so pode inserir o A
			if(ElementoTopoM(mesa,2).naipe == tiponaipechar && ElementoTopoM(mesa,2).numero == 1){
				//se a carta que ele quer colocar no naipe � realmente igual ao naipe da pilha destino
				//e tambem se o numero que ele quer colocar � a carta A
					Push(naipe,PopM(mesa,2));
					if(PMVaziaM(mesa.TOPO2,2) && !PMVaziaM(mesa.TOPO1,1))
						PushM(mesa,PopM(mesa,1),2);
			}else{
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Este deslocamento est� incorreto (naipe diferente /ou/ carta incorreta)");
				digitar();
				getch();
			}
			
			
		}else{
			if(ElementoTopoM(mesa,2).naipe == tiponaipechar && ElementoTopoM(mesa,2).numero == ElementoTopo(naipe).numero+1){
				//se a carta que ele quer colocar no naipe � realmente igual ao naipe da pilha destino
				//e tambem se o numero que ele quer colocar � realmente o proximo da pilha
				Push(naipe,PopM(mesa,2));
				if(PMVaziaM(mesa.TOPO2,2) && !PMVaziaM(mesa.TOPO1,1))
					PushM(mesa,PopM(mesa,1),2);
				
			}else{
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Este deslocamento est� incorreto (naipe diferente /ou/ carta incorreta)");
				digitar();
				getch();
			}
			
		}
	}else{
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("Voce esta tentando retirar de uma pilha vazia!!!!");
		digitar();
		getch();
	}
	
	
	
}

void comprarCarta(TpPilha &montante,TpPilha &resto){
	
	if(montante.topo > -1 || resto.topo > -1){
		if(!PilhaVazia(montante.topo)){//se ainda tiver carta no montante
			Push(resto,Pop(montante));
		}else{//se acabou as cartas no montante
			//passar tudo para o montante e depois comprar
			while(!PilhaVazia(resto.topo)){
				Push(montante,Pop(resto));	
			}
			Push(resto,Pop(montante));
		}
	}
}

void restoPmesa(TpPilha &resto,TpPilhaM &mesa){
	char tiponaipechar;
	int x,y;
	TpCarta aux;
	if(!PilhaVazia(resto.topo)){
		aux = ElementoTopo(resto);
		if(aux.numero==13 && PMVaziaM(mesa.TOPO2,2)){
				PushM(mesa,Pop(resto),2);
			
		}else{
			if(aux.naipe == 'C' || aux.naipe == 'O'){
				if((ElementoTopoM(mesa,2).naipe == 'P' || ElementoTopoM(mesa,2).naipe  == 'E') && aux.numero == ElementoTopoM(mesa,2).numero-1){
					PushM(mesa,Pop(resto),2);
					
				}
				
			}else if(aux.naipe == 'P' || aux.naipe == 'E'){
				if((ElementoTopoM(mesa,2).naipe  == 'C' || ElementoTopoM(mesa,2).naipe  == 'O') && aux.numero == ElementoTopoM(mesa,2).numero-1){
					PushM(mesa,Pop(resto),2);
					
				}
			}else{
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("nao e possivel fazer o movimento!!!!");
				digitar();
				getch();
			}
		}
		
	}else{
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("Voce esta tentando retirar do resto que esta vazio!!!!");
		digitar();
		getch();
	}

}

void restoPnaipe(TpPilha &resto, TpPilha &naipe,int tiponaipe){
	
	char tiponaipechar;
	int x,y;
	TpCarta aux;
	switch(tiponaipe){
		case 0:
			tiponaipechar = 'C';
			break;
		case 1:
			tiponaipechar = 'O';
			break;
		case 2:
			tiponaipechar = 'P';
			break;
		case 3:
			tiponaipechar = 'E';
			break;
	}
	aux = ElementoTopo(resto);
	
	if(!PilhaVazia(resto.topo)){
		if(PilhaVazia(naipe.topo)){
			if(aux.naipe == tiponaipechar && aux.numero == 1){

					Push(naipe,Pop(resto));
			}else{
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Este deslocamento est� incorreto (naipe diferente /ou/ carta incorreta)");
				digitar();
				getch();
			}
			
			
		}else{
			if(aux.naipe == tiponaipechar && aux.numero == ElementoTopo(naipe).numero+1){
			
				Push(naipe,Pop(resto));
				
			}else{
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Este deslocamento est� incorreto (naipe diferente /ou/ carta incorreta)");
				digitar();
				getch();
			}
			
		}
		
	}else{
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("Voce esta tentando retirar do resto que esta vazio!!!!");
		digitar();
		getch();
	}
	
	
	
}

void printarcount(int count){
	int x=4,y=52,j;
	gotoxy(x,y);printf("%c%c%c%c%c%c%c%c%c%c%c%c" ,	201 ,205,205,205,205,205,205,205,205,205,205,187  );y++;
	gotoxy(x,y);printf("%cMovimentos%c",186,186);y++;
	gotoxy(x,y);printf("%c          %c",186,186);y++;
	gotoxy(x,y);printf("%c          %c",186,186);
	if(count>99)
		j=x+4;
	else
		j=x+5;
	gotoxy(j,y);printf("%d",count);y++;
	
	gotoxy(x,y);printf("%c%c%c%c%c%c%c%c%c%c%c%c" ,	200 ,205,205,205,205,205,205,205,205,205,205,188  );y++;
}

void Jogar(void){
	//***********************************************************************
	//definindo
	char a;
	int i, x,j,k,count=0,y;
	TpPilhaM mesa[7];
	TpPilha montante,resto,aux;
	TpPilha naipes[4];
	TpCarta aux2;
	//***********************************************************************
	srand( (unsigned)time(NULL) );
	//***********************************************************************
	//inicializar todas as pilhas
	for(i=0;i<7;i++){
        InicializarM(mesa[i]);
    }
    for(i=0;i<4;i++){
        Inicializar(naipes[i]);
    }
    Inicializar(montante);
    Inicializar(resto);
    Inicializar(aux);
	//***********************************************************************
	
	//***********************************************************************
	RetornarBarallhoAleatorio(montante); //gerar baralho
	//inserir todas as cartas em seus respectivos lugares para come�ar o jogo
	for(j=0;j<7;j++){
		for(k=0; k<j;k++){
			aux2 = Pop(montante);
			PushM(mesa[j],aux2,1);
		}
       	aux2 = Pop(montante);
		PushM(mesa[j],aux2,2);
	}
	//***********************************************************************
	//fun��o para printar o baralho na tela
	Moldura();
	Printarquadrante1(montante,resto);
	Printarquadrante2(mesa);
	Printarquadrante3(naipes);
	digitar();// comando para limpar o lugar de digitar e colocar ponteiro la
	
	//**********************************************************************
	//enquanto n�o completar todos os naipes ou o montante for maior que zero o jogo roda.
	while((!PilhaVazia(montante.topo) || !PilhaVazia(resto.topo))  ||  (mesa[0].TOPO1>-1 || mesa[1].TOPO1>-1 || mesa[2].TOPO1>-1 || mesa[3].TOPO1>-1 || mesa[4].TOPO1>-1 || mesa[5].TOPO1>-1 || mesa[6].TOPO1>-1)) {
		int x,y;
		char op;
		int orig,dest,qtd;
		
		x=21;y=53;
		limparquadrante4();
		gotoxy(x,y);printf("[1] Mover carta (origem / destino / quantidade)");y++;
		gotoxy(x,y);printf("[2] Comprar carta");y++;
		digitar();
		op = getch();
		
		
		
		if(op=='1'){//se ele escolheu mover
		//*******************************************************************************************************
		//printar pergunta
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("Digite (em ordem) Origem / Destino / Quantidade");y++;
		//entrada da origem destino e qtd
		digitar();
		scanf("%d %d %d",&orig,&dest,&qtd);
		if( dest>0 && dest<8 && orig>0 && orig<12 && orig!=dest){
		//MOVER DE MESA PARA MESA
		//********************************************	
			mesaPmesa(mesa[orig-1],mesa[dest-1],qtd);
			limparquadrante2();
			Printarquadrante2(mesa);
			
		//********************************************	
		}else if( dest>=8 && dest<12 && orig>0 && orig<12 && orig!=dest){
		//MOVER DE MESA PARA NAIPES
		//********************************************
			if(qtd!=1){
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Nao e poss�vel mandar mais de uma carta para NAIPES por vez!");
				digitar();
				getch();
			}else{
				mesaPnaipe(mesa[orig-1],naipes[dest-8],dest-8);
				limparquadrante2();
				Printarquadrante2(mesa);
				limparquadrante3();
				Printarquadrante3(naipes);
				
				
			}			
		//********************************************	
		}else if( dest>=1 && dest<8 && orig == 12 && orig!=dest){
		//MOVER DE RESTO PARA MESA
		//********************************************
			if(qtd!=1){
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Nao e poss�vel mandar mais de uma carta para MESA por vez!");
				digitar();
				getch();
			}else{
				restoPmesa(resto,mesa[dest-1]);
				limparquadrante2();
				Printarquadrante2(mesa);
				limparquadrante1();
				Printarquadrante1(montante,resto);
				
			}
		//********************************************	
		}else if(dest>=8 && dest<=11 && orig == 12 && orig!=dest){
			if(qtd!=1){
				x=21,y=54;
				limparquadrante4();
				gotoxy(x,y);printf("Nao e poss�vel mandar mais de uma carta para NAIPE por vez!");
				digitar();
				getch();
			}else{
				restoPnaipe(resto,naipes[dest-8],dest-8);
				limparquadrante1();
				Printarquadrante1(montante,resto);
				limparquadrante3();
				Printarquadrante3(naipes);
				
			}
		
		
		}else{
		
		// se for invalido origem ou destino
		limparquadrante4();
		x=21,y=54;
		if(orig==dest)
		{
		gotoxy(x,y);printf("DESTINO E ORIGEM NAO PODEM SER IGUAIS (enter - sair)");
		}
		else{
		gotoxy(x,y);printf("DIGITE UMA origem / destino VALIDOS! (enter - sair)");
		}
		digitar();
		getch();
		}
		//***************************************************************************************************
		}
		else if(op=='2'){//se ele escolheu comprar carta
		//***************************************************************************************************
			comprarCarta(montante,resto);
			limparquadrante1();
			Printarquadrante1(montante,resto);
			
		//***************************************************************************************************
		}else{
		x=21,y=54;
		limparquadrante4();
		gotoxy(x,y);printf("DIGITE UMA OPCAO VALIDA (enter - sair)");
		digitar();
		getch();
		}
		count++;
		printarcount(count);
    }
	//***********************************************************************
	clrscr();
	x=1;y=1;
	gotoxy(x,y);
	gotoxy(x,y);printf("888     888 8888888 88888888888  .d88888b.  8888888b.  8888888        d8888 ");y++;
	gotoxy(x,y);printf("888     888   888       888     d88P   Y88b 888   Y88b   888         d88888 ");y++;
	gotoxy(x,y);printf("888     888   888       888     888     888 888    888   888        d88P888 ");y++;
	gotoxy(x,y);printf("Y88b   d88P   888       888     888     888 888   d88P   888       d88P 888 ");y++;
	gotoxy(x,y);printf(" Y88b d88P    888       888     888     888 8888888P     888      d88P  888 ");y++;
	gotoxy(x,y);printf("   Y888P      888       888     Y88b. .d88P 888  T88b    888    d8888888888 ");y++;
	gotoxy(x,y);printf("    Y8P     8888888     888       Y88888P   888   T88b 8888888 d88P     888");y++;

	
}

int main(void){
    Jogar();
    return 0;
}
